import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
const port=Number(process.env.PORT||8000), root=path.resolve(import.meta.dirname);
// Optional local environment file for simple Windows setup; never expose it over HTTP.
const envFile=path.join(root,'.env.local');
if(fs.existsSync(envFile)){
 for(const line of fs.readFileSync(envFile,'utf8').split(/\r?\n/)){
  const match=line.match(/^PINATA_JWT\s*=\s*(.+)$/);
  if(match&&!process.env.PINATA_JWT)process.env.PINATA_JWT=match[1].trim().replace(/^['"]|['"]$/g,'');
 }
}
const allowedOrigins = new Set([`http://localhost:${port}`, `http://127.0.0.1:${port}`]);
if (process.env.PUBLIC_ORIGIN) {
  try { allowedOrigins.add(new URL(process.env.PUBLIC_ORIGIN).origin); }
  catch { throw new Error('PUBLIC_ORIGIN must be a valid HTTPS URL'); }
}
// On public hosting metadata uploads are disabled unless explicitly opted in.
// With public uploads enabled, the owner must monitor and restrict Pinata quota.
const uploadsEnabled = process.env.PUBLIC_METADATA_UPLOADS === 'true';
const perIpUploads = new Map();
let lastUploadAt=0;
let globalHourStart=Date.now(), globalHourCount=0;
function rateAllowed(req) {
 const now=Date.now();
 if (now-globalHourStart >= 3600000) {globalHourStart=now;globalHourCount=0;}
 if (globalHourCount>=30) return false;
 // Reverse proxies can share a source address. This is a coarse protection, not authentication.
 const ip=req.socket.remoteAddress||'unknown';
 const prev=perIpUploads.get(ip)||[];
 const recent=prev.filter(t=>now-t<3600000);
 if (recent.length>=10) return false;
 recent.push(now);perIpUploads.set(ip,recent);globalHourCount++;
 return true;
}
const json=(res,code,obj)=>{res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(obj))};
async function pinFile(bytes,type){const form=new FormData();form.append('file',new Blob([bytes],{type}),'token-logo.'+({ 'image/png':'png','image/jpeg':'jpg','image/webp':'webp'}[type]));const r=await fetch('https://api.pinata.cloud/pinning/pinFileToIPFS',{method:'POST',headers:{Authorization:`Bearer ${process.env.PINATA_JWT}`},body:form});const j=await r.json();if(!r.ok||!j.IpfsHash)throw Error('Pinata image upload failed: '+JSON.stringify(j).slice(0,200));return `https://gateway.pinata.cloud/ipfs/${j.IpfsHash}`}
async function pinJson(metadata){const r=await fetch('https://api.pinata.cloud/pinning/pinJSONToIPFS',{method:'POST',headers:{Authorization:`Bearer ${process.env.PINATA_JWT}`,'Content-Type':'application/json'},body:JSON.stringify({pinataContent:metadata,pinataMetadata:{name:'SolLaunch '+metadata.symbol}})});const j=await r.json();if(!r.ok||!j.IpfsHash)throw Error('Pinata metadata upload failed: '+JSON.stringify(j).slice(0,200));return `https://gateway.pinata.cloud/ipfs/${j.IpfsHash}`}
const server=http.createServer(async(req,res)=>{try{if(req.url==='/health' && req.method==='GET')return json(res,200,{status:'ok',network:'devnet',metadataUploadsEnabled:uploadsEnabled});
if(req.url==='/api/metadata'&&req.method==='POST'){
 if(!uploadsEnabled)return json(res,503,{error:'Metadata uploads are disabled by the site operator. Set PUBLIC_METADATA_UPLOADS=true only after setting up controls and Pinata quota limits.'});
 if(!rateAllowed(req))return json(res,429,{error:'Upload quota reached. Try later.'});
 const origin=req.headers.origin;
 if(origin&&!allowedOrigins.has(origin))return json(res,403,{error:'Cross-origin metadata upload blocked'});
 if(!(req.headers['content-type']||'').startsWith('application/json'))return json(res,415,{error:'Content-Type must be application/json'});
 if(Date.now()-lastUploadAt<1500)return json(res,429,{error:'Please wait before the next upload'});
 lastUploadAt=Date.now();
if(!process.env.PINATA_JWT)return json(res,503,{error:'PINATA_JWT is not configured. Set it in your terminal before starting the server.'});let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>3_500_000)return json(res,413,{error:'Upload too large'})}
const x=JSON.parse(raw);if(typeof x.name!=='string'||typeof x.symbol!=='string'||x.name.length>32||!/^[A-Z0-9]{2,10}$/.test(x.symbol)||typeof x.description!=='string'||x.description.length>2000)return json(res,400,{error:'Invalid metadata fields'});
let image=x.logoUrl;if(x.imageBase64){if(!['image/png','image/jpeg','image/webp'].includes(x.imageType))return json(res,400,{error:'Unsupported image type'});if(!/^[A-Za-z0-9+/]+={0,2}$/.test(x.imageBase64))return json(res,400,{error:'Invalid base64 payload'});const bytes=Buffer.from(x.imageBase64,'base64');if(bytes.length>2_000_000)return json(res,413,{error:'Image too large'});image=await pinFile(bytes,x.imageType)}
if(!image||!/^https:\/\//.test(image))return json(res,400,{error:'HTTPS image URL or image upload required'});const metadata={name:x.name,symbol:x.symbol,description:x.description,image,properties:{files:[{uri:image,type:x.imageType||'image/png'}],category:'image'}};const uri=await pinJson(metadata);return json(res,200,{uri,image})}
if(req.method!=='GET')return json(res,405,{error:'Method not allowed'});const route=decodeURIComponent(req.url.split('?')[0]);const rel=route==='/'?'index.html':route.slice(1);const full=path.resolve(root,rel);if(!full.startsWith(root+path.sep))return json(res,403,{error:'Forbidden'});const ext=path.extname(full);if(!['.html','.js','.css','.png','.ico'].includes(ext))return json(res,404,{error:'Not found'});const data=await fs.promises.readFile(full);res.writeHead(200,{'Content-Type':{'.html':'text/html; charset=utf-8','.js':'application/javascript','.css':'text/css','.png':'image/png','.ico':'image/x-icon'}[ext],'X-Content-Type-Options':'nosniff','Cache-Control':'no-store','Referrer-Policy':'no-referrer','X-Frame-Options':'DENY','Strict-Transport-Security':'max-age=31536000; includeSubDomains','Permissions-Policy':'camera=(), microphone=(), geolocation=()','Content-Security-Policy':"default-src 'self'; script-src 'self' 'unsafe-inline'; connect-src 'self' https: wss:; img-src 'self' https: data:; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'"});res.end(data)}catch(e){json(res,e.code==='ENOENT'?404:500,{error:e.message})}});
server.listen(port,'0.0.0.0',()=>console.log(`SolLaunch server listening on port ${port} (Devnet only)`));
