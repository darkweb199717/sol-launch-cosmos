# SolLaunch — public website deployment (Devnet only)

This is an **experimental public Devnet preview**, not a Mainnet or trading launchpad. Never enter your seed phrase. Pool creation and swaps are unavailable.

## Deploy with GitHub + Render

1. Put the contents of this folder in a new private GitHub repository (DO NOT commit `.env.local`, keys or a Pinata JWT).
2. In Render select **New > Blueprint**, connect the repository and apply `render.yaml`.
3. Set `PUBLIC_ORIGIN` to the exact HTTPS URL Render assigned, such as `https://sollaunch-devnet.onrender.com`. The origin must match the URL seen in the browser. Set `PINATA_JWT` as a secret (not in the repository).
4. Initially keep `PUBLIC_METADATA_UPLOADS=false`. The site and wallet connections can go public; minting that needs IPFS uploads will show a controlled error until uploads are enabled.
5. Verify `https://YOUR-RENDER-DOMAIN/health`, page load, browser console and Phantom network detection.
6. Test using a disposable Devnet wallet. Only after checking on-chain mint, metadata, and transaction confirmation should you consider `PUBLIC_METADATA_UPLOADS=true`. **Public metadata uploads spend your Pinata account quota.** Add CAPTCHA, authenticated quotas, bot protection, monitoring, and abuse protection before enabling uploads for everyone. Current throttles are coarse and not a production abuse defense.
7. Add a custom domain in Render and follow its DNS instructions. HTTPS is required for Phantom on a public site.

## What this deploys

- Public dashboard and Phantom Devnet connection
- Explore and dashboard of browser-local token records; wallet token lookup from RPC
- Devnet token creation code and on-chain metadata flow (unverified end to end)
- IPFS upload endpoint **disabled by default** on the public web service
- Price and liquidity planning only, no Raydium pool or swap functionality

## Command line smoke tests

```sh
npm install
npm run setup
npm run check
npm start
# from another terminal:
curl http://localhost:8000/health
```

## Readiness before real funds

You must separately implement and test production RPC infrastructure, signed transaction simulations, proper authentication and per-wallet upload quotas, monitoring, a server-side indexer, Raydium pool/swaps, comprehensive integration testing and an independent security review before considering Mainnet transactions. The UI is hard-coded to Devnet and verifies its genesis hash. **Do not remove the Devnet check for a public launch.**
