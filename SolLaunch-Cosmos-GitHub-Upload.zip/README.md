# Deployment update — public Devnet preview

See **DEPLOY.md** for the GitHub + Render instructions. Public metadata uploads are disabled by default to protect the Pinata account. For local token tests, set `PUBLIC_METADATA_UPLOADS=true` in the server environment; note that `server.mjs` reads only `PINATA_JWT` from `.env.local`, so other settings need shell environment variables.

# SolLaunch Cosmos v3.0 — space-themed Devnet launch dashboard

A redesigned SolLaunch HTML dashboard inspired by the *genre* of Solana launchpad sites. This is an original UI, not a copy of Cosmic Launch source code or branding. Cosmic Launch blocked automated inspection when this edition was prepared, so pixel-perfect matching was not possible.

## Features

- Responsive dark, space-themed dashboard; Overview, Discover, Create, My Launches and Liquidity Lab.
- Browser-side Phantom wallet connection / trusted reconnect and Solana **Devnet** verification.
- Real classic SPL token minting flow using Phantom signatures; optional keep-mint and freeze authorities.
- On-chain Metaplex metadata instruction; uploaded JSON and token images via a local Pinata IPFS proxy.
- Phantom approval, transaction confirmation handling and on-chain verification of supply, mint authority and metadata account existence.
- Devnet SOL balance lookup and 1 SOL airdrop request (faucet rate limits may apply).
- Wallet SPL token-account lookup; local saved token cards with search, sort, export and clear.
- Liquidity price/FDV planner. **Raydium pool creation, swaps, token-market indexing and Mainnet are NOT present.**

## Windows quick start

1. Install Node.js 22+ and Phantom browser extension.
2. Extract the ZIP. Open the `SolLaunch-Cosmic-v3` folder.
3. Copy `.env.example` to `.env.local`, put your real **Pinata JWT** after `PINATA_JWT=`, and keep the file PRIVATE. The JWT needs Pinata pinFileToIPFS and pinJSONToIPFS permissions for the older pinning APIs used here.
4. Double click `start-windows.bat`. It runs `npm install`, copies the pinned self-hosted Solana library into `vendor/`, and starts the localhost server.
5. Open **http://localhost:8000** in Chrome or Edge with Phantom installed. Switch your Phantom network to **Devnet**.
6. Connect Phantom, request test SOL if necessary, and create a sample token. Review the transaction carefully before signing.

## Terminal (Windows, macOS, Linux)

```sh
npm install
npm run setup
npm start
```

Then open `http://localhost:8000`. You can alternatively set the `PINATA_JWT` environment variable instead of using `.env.local`. For privacy, do not commit `.env.local` to version control or share it in screenshots.

## Why not open index.html directly?

The HTML renders the interface locally, but token creation relies on `vendor/solana-web3.iife.min.js` (generated in `npm run setup`) and a **local server** to securely upload token metadata to IPFS. Opening a `file://` URL is not sufficient for full wallet/IPFS functionality.

## Scope, limits & important safety

- **Devnet only.** Test SOL has no real value. The app checks the Devnet genesis hash before sending transactions.
- The token-create feature has been **syntax tested**, but **has not passed an end-to-end live Phantom + Pinata + Metaplex Devnet mint test in this environment**. Treat it as experimental until you verify a real mint using a test wallet and Devnet Explorer. Never connect a Mainnet wallet with funds to an untested local project.
- The liquidity planner **does not** deploy pools. Tokens created by this flow are **not automatically tradable**.
- The public Devnet RPC is rate-limited. Use the RPC control to set a trusted HTTPS Devnet RPC provider. Avoid untrusted RPC URLs.
- Launch counts on the overview are **browser-local records**, not sitewide or market stats. The Discover tab is local only; wallet holdings are queried directly from Solana.
- Metadata relies on your own Pinata account. Legacy Pinata pinning endpoints and gateway behavior may change, and image metadata compatibility depends on wallets/explorers.
- Running the included server is intended for **localhost development**. For production, add authentication, per-user rate limits, robust secret isolation, security review, transaction simulation, proper infrastructure, and monitoring.
- No fees are sent to a SolLaunch treasury wallet; network rent / fees still apply on Devnet.

## File contents

- `index.html` — complete dashboard HTML/CSS/JS interface and token creation integration.
- `server.mjs` — localhost-only static server / Pinata IPFS upload proxy.
- `setup.mjs` — copies the pinned dependency into `vendor/` for self-hosted loading.
- `start-windows.bat` — Windows launcher.
- `.env.example` — Pinata JWT configuration template.

## Recommended production roadmap

1. Integration-test Phantom signing and Metaplex metadata creation using fresh Devnet wallets.
2. Add a tested on-chain token indexer and audit all frontend / server code.
3. Add Raydium CPMM or LaunchLab Devnet SDK support with correctly verified program IDs and signature simulation.
4. Only then evaluate Mainnet deployment with an independent security audit.
