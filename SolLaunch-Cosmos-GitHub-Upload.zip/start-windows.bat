@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Node.js 22 or newer is required. Install Node.js from https://nodejs.org/
  pause
  exit /b 1
)
if not exist "node_modules" (
  call npm install
  if errorlevel 1 goto fail
)
if not exist "vendor\solana-web3.iife.min.js" (
  call npm run setup
  if errorlevel 1 goto fail
)
echo.
echo SolLaunch Cosmos: open http://localhost:8000 in Chrome or Edge with Phantom.
echo.
call npm start
pause
exit /b 0
:fail
echo Setup failed. See the error above.
pause
exit /b 1
